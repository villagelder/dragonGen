package org.dv.data.pdfdata;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDCheckbox;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.pdmodel.interactive.form.PDTextbox;

public class PrintCharacter {
	private static PDDocument _pdfDocument;

	public static void main(String[] args) {

		try {
			_pdfDocument = PDDocument.load("src/org/dv/data/pdfdata/CharacterSheet_3Pgs_ Complete.pdf");
			_pdfDocument.setAllSecurityToBeRemoved(true);

			// int i = _pdfDocument.getNumberOfPages();

			// COSDocument doc = _pdfDocument.getDocument();
			// PDDocumentCatalog docCatalog = _pdfDocument.getDocumentCatalog();

			PDAcroForm acroForm = _pdfDocument.getDocumentCatalog().getAcroForm();

			// List acrFields = new ArrayList();
			// acrFields = acroForm.getFields();

			// Iterator fieldsIter = acroForm.getFields().iterator();
			// while (fieldsIter.hasNext()) {
			// PDField field = (PDField) fieldsIter.next();
			// System.out.println(field.getFullyQualifiedName().trim());
			// }

			// Character Name
			acroForm.getField("CharacterName").getDictionary().setString(COSName.DA, "/Helv 14 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CharacterName").getDictionary()))
					.setValue("Monsieur Mouseroy");

			// Class Level
			acroForm.getField("ClassLevel").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ClassLevel").getDictionary()))
					.setValue("Pacifist 19");

			// Background
			acroForm.getField("Background").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Background").getDictionary())).setValue("Charlatan");

			// Player Name
			acroForm.getField("PlayerName").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("PlayerName").getDictionary()))
					.setValue("Wilbur Walksalot");

			// Race
			acroForm.getField("Race ").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Race ").getDictionary())).setValue("Mouse");

			// Alignment
			acroForm.getField("Alignment").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Alignment").getDictionary()))
					.setValue("Chaotic Neutral");

			// Experience Points
			acroForm.getField("XP").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("XP").getDictionary())).setValue("9");

			// -----------------------BEGIN FIRST COLUMN-----------------------

			// STATS
			// Strength
			acroForm.getField("STR").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("STR").getDictionary())).setValue("5");
			// Dexterity
			acroForm.getField("DEX").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("DEX").getDictionary())).setValue("13");
			// Constitution
			acroForm.getField("CON").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CON").getDictionary())).setValue("10");
			// Intelligence
			acroForm.getField("INT").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("INT").getDictionary())).setValue("5");
			// Wisdom
			acroForm.getField("WIS").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("WIS").getDictionary())).setValue("15");
			// Charisma
			acroForm.getField("CHA").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CHA").getDictionary())).setValue("2");

			// STAT MODIFIERS
			// Strength Modifier
			acroForm.getField("STRmod").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("STRmod").getDictionary())).setValue("+1");
			// Dexterity Modifier
			acroForm.getField("DEXmod ").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("DEXmod ").getDictionary())).setValue("+2");
			// Constitution Modifier
			acroForm.getField("CONmod").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CONmod").getDictionary())).setValue("+3");
			// Intelligence Modifier
			acroForm.getField("INTmod").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("INTmod").getDictionary())).setValue("+4");
			// Wisdom Modifier
			acroForm.getField("WISmod").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("WISmod").getDictionary())).setValue("+5");
			// Charisma Modifier
			acroForm.getField("CHamod").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CHamod").getDictionary())).setValue("+6");

			// INSPIRATION
			acroForm.getField("Inspiration").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Inspiration").getDictionary())).setValue("+5");

			// PROFICIENCY BONUS
			acroForm.getField("ProfBonus").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ProfBonus").getDictionary())).setValue("+6");

			// SAVING THROWS
			// Saving Throw Strength Check Box
			((PDCheckbox) acroForm.getField("Check Box 11")).check();
			// Saving Throw Strength
			acroForm.getField("ST Strength").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Strength").getDictionary())).setValue("+4");

			// Saving Throw Dexterity Check Box
			((PDCheckbox) acroForm.getField("Check Box 18")).check();
			// Saving Throw Dexterity
			acroForm.getField("ST Dexterity").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Dexterity").getDictionary())).setValue("+5");

			// Saving Throw Constitution Check Box
			((PDCheckbox) acroForm.getField("Check Box 19")).check();
			// Saving Throw Constitution
			acroForm.getField("ST Constitution").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Constitution").getDictionary())).setValue("+6");

			// Saving Throw Intelligence Check Box
			((PDCheckbox) acroForm.getField("Check Box 20")).check();
			// Saving Throw Intelligence
			acroForm.getField("ST Intelligence").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Intelligence").getDictionary())).setValue("+7");

			// Saving Throw Wisdom Check Box
			((PDCheckbox) acroForm.getField("Check Box 21")).check();
			// Saving Throw Wisdom
			acroForm.getField("ST Wisdom").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Wisdom").getDictionary())).setValue("+8");

			// Saving Throw Charisma Check Box
			((PDCheckbox) acroForm.getField("Check Box 22")).check();
			// Saving Throw Charisma
			acroForm.getField("ST Charisma").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Charisma").getDictionary())).setValue("+9");

			// SKILLS
			// Acrobatics Check Box
			((PDCheckbox) acroForm.getField("Check Box 23")).check();
			// Acrobatics Skill Modifier
			acroForm.getField("Acrobatics").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Acrobatics").getDictionary())).setValue("+1");
			// Animal Handling Check Box
			((PDCheckbox) acroForm.getField("Check Box 24")).check();
			// Animal Handling Skill Modifier
			acroForm.getField("Animal").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Animal").getDictionary())).setValue("+2");
			// Arcana Check Box
			((PDCheckbox) acroForm.getField("Check Box 25")).check();
			// Arcana Skill Modifier
			acroForm.getField("Arcana").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Arcana").getDictionary())).setValue("+3");
			// Athletics Check Box
			((PDCheckbox) acroForm.getField("Check Box 26")).check();
			// Athletics Skill Modifier
			acroForm.getField("Athletics").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Athletics").getDictionary())).setValue("+4");
			// Deception Check Box
			((PDCheckbox) acroForm.getField("Check Box 27")).check();
			// Deception Skill Modifier
			acroForm.getField("Deception ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Deception ").getDictionary())).setValue("+5");
			// History Check Box
			((PDCheckbox) acroForm.getField("Check Box 28")).check();
			// History Skill Modifier
			acroForm.getField("History ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("History ").getDictionary())).setValue("+6");
			// Insight Check Box
			((PDCheckbox) acroForm.getField("Check Box 29")).check();
			// Insight Skill Modifier
			acroForm.getField("Insight").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Insight").getDictionary())).setValue("+7");
			// Intimidation Check Box
			((PDCheckbox) acroForm.getField("Check Box 30")).check();
			// Intimidation Skill Modifier
			acroForm.getField("Intimidation").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Intimidation").getDictionary())).setValue("+8");
			// Investigation Check Box
			((PDCheckbox) acroForm.getField("Check Box 31")).check();
			// Investigation Skill Modifier
			acroForm.getField("Investigation ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Investigation ").getDictionary())).setValue("+9");
			// Medicine Check Box
			((PDCheckbox) acroForm.getField("Check Box 32")).check();
			// Medicine Skill Modifier
			acroForm.getField("Medicine").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Medicine").getDictionary())).setValue("+8");
			// Nature Check Box
			((PDCheckbox) acroForm.getField("Check Box 33")).check();
			// Nature Skill Modifier
			acroForm.getField("Nature").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Nature").getDictionary())).setValue("+7");
			// Perception Check Box
			((PDCheckbox) acroForm.getField("Check Box 34")).check();
			// Perception Skill Modifier
			acroForm.getField("Perception ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Perception ").getDictionary())).setValue("+6");
			// Performance Check Box
			((PDCheckbox) acroForm.getField("Check Box 35")).check();
			// Performance Skill Modifier
			acroForm.getField("Performance").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Performance").getDictionary())).setValue("+5");
			// Persuasion Check Box
			((PDCheckbox) acroForm.getField("Check Box 36")).check();
			// Persuasion Skill Modifier
			acroForm.getField("Persuasion").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Persuasion").getDictionary())).setValue("+4");
			// Religion Check Box
			((PDCheckbox) acroForm.getField("Check Box 37")).check();
			// Religion Skill Modifier
			acroForm.getField("Religion").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Religion").getDictionary())).setValue("+3");
			// SleightofHand Check Box
			((PDCheckbox) acroForm.getField("Check Box 38")).check();
			// SleightofHand Skill Modifier
			acroForm.getField("SleightofHand").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SleightofHand").getDictionary())).setValue("+2");
			// Stealth Check Box
			((PDCheckbox) acroForm.getField("Check Box 39")).check();
			// Stealth Skill Modifier
			acroForm.getField("Stealth ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Stealth ").getDictionary())).setValue("+1");
			// Survival Check Box
			((PDCheckbox) acroForm.getField("Check Box 40")).check();
			// Survival Skill Modifier
			acroForm.getField("Survival").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Survival").getDictionary())).setValue("+2");

			acroForm.getField("Passive").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Passive").getDictionary())).setValue("+5");

			acroForm.getField("ProficienciesLang").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ProficienciesLang").getDictionary()))
					.setValue("Mouseish\nSqueak Slang");

			// -----------------------BEGIN SECOND COLUMN-----------------------
			acroForm.getField("AC").getDictionary().setString(COSName.DA, "/Helv 14 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("AC").getDictionary())).setValue("19");

			acroForm.getField("Initiative").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Initiative").getDictionary())).setValue("+1");

			acroForm.getField("Speed").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Speed").getDictionary())).setValue("15 ft");

			acroForm.getField("HPMax").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("HPMax").getDictionary())).setValue("9");

			// Hit Points
			// acroForm.getField("HPCurrent").setValue("219");
			acroForm.getField("HPCurrent").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("HPCurrent").getDictionary())).setValue("9");

			acroForm.getField("HPTemp").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("HPTemp").getDictionary())).setValue("1");

			acroForm.getField("HDTotal").setValue("X");

			acroForm.getField("HD").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("HD").getDictionary())).setValue("�d8 (1 hp)");

			// DEATH SAVES SUCCESSES CHECK BOXES
			// Success Check Box 1
			((PDCheckbox) acroForm.getField("Check Box 12")).check();
			// Success Check Box 2
			((PDCheckbox) acroForm.getField("Check Box 13")).check();
			// Success Check Box 3
			((PDCheckbox) acroForm.getField("Check Box 14")).check();

			// DEATH SAVES FAILURES CHECK BOXES
			// Failure Check Box 1
			((PDCheckbox) acroForm.getField("Check Box 15")).check();
			// Failure Check Box 2
			((PDCheckbox) acroForm.getField("Check Box 16")).check();
			// Failure Check Box 3
			((PDCheckbox) acroForm.getField("Check Box 17")).check();

			// Weapon 1
			// acroForm.getField("Wpn Name").setValue("Machine Gun");
			acroForm.getField("Wpn Name").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn Name").getDictionary())).setValue("Machine Gun");
			// acroForm.getField("Wpn1 AtkBonus").setValue("+25");
			acroForm.getField("Wpn1 AtkBonus").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn1 AtkBonus").getDictionary())).setValue("+25");
			// acroForm.getField("Wpn1 Damage").setValue("10d20");
			acroForm.getField("Wpn1 Damage").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn1 Damage").getDictionary())).setValue("10d20");
			// Weapon 2
			// acroForm.getField("Wpn Name 2").setValue("X");
			acroForm.getField("Wpn Name 2").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn Name 2").getDictionary()))
					.setValue("Arks Toothpck");
			// acroForm.getField("Wpn2 AtkBonus ").setValue("X");
			acroForm.getField("Wpn2 AtkBonus ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn2 AtkBonus ").getDictionary())).setValue("+6");
			// acroForm.getField("Wpn2 Damage ").setValue("X");
			acroForm.getField("Wpn2 Damage ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn2 Damage ").getDictionary())).setValue("2d4+3");
			// Weapon 3
			// acroForm.getField("Wpn Name 3").setValue("X");
			acroForm.getField("Wpn Name 3").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn Name 3").getDictionary()))
					.setValue("Cat'o 9 Tails");
			// acroForm.getField("Wpn3 AtkBonus ").setValue("X");
			acroForm.getField("Wpn3 AtkBonus  ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn3 AtkBonus  ").getDictionary())).setValue("+2");
			// acroForm.getField("Wpn3 Damage ").setValue("X");
			acroForm.getField("Wpn3 Damage ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn3 Damage ").getDictionary())).setValue("1d6");

			acroForm.getField("AttacksSpellcasting").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("AttacksSpellcasting").getDictionary())).setValue(
					"Base Attack/Grapple: +0/-21\n" + "Attack: Bite +9 melee (1)\n" + "Full Attack: Bite +9 melee (1)");

			acroForm.getField("CP").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CP").getDictionary())).setValue("999");
			acroForm.getField("SP").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SP").getDictionary())).setValue("999");
			acroForm.getField("EP").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("EP").getDictionary())).setValue("999");
			acroForm.getField("GP").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("GP").getDictionary())).setValue("999");
			acroForm.getField("PP").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("PP").getDictionary())).setValue("999");

			acroForm.getField("Equipment").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Equipment").getDictionary())).setValue("Fur");

			// -----------------------BEGIN THIRD COLUMN-----------------------
			acroForm.getField("PersonalityTraits ").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("PersonalityTraits ").getDictionary()))
					.setValue("Environment: Any\n" + "Organization: Mischief (10-100)");

			acroForm.getField("Ideals").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Ideals").getDictionary()))
					.setValue("Squeek! Something small darts \nout of the corner of your eye");

			acroForm.getField("Bonds").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Bonds").getDictionary()))
					.setValue("and flees into a small hole \nin the wall.");

			acroForm.getField("Flaws").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Flaws").getDictionary())).setValue("Eeek! A mouse!");

			acroForm.getField("Features and Traits").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Features and Traits").getDictionary()))
					.setValue("Speed: 15 ft. (3 squares), \nclimb 15 ft\n"
							+ "Armor Class: 19 (+8 size, +1 Dex), \ntouch 19, flat-footed 18\n"
							+ "Space/Reach: � ft./0 ft.\n" + "Special Qualities: Low-light vision, \nscent\n"
							+ "Saves: Fort +2, Ref +3, Will +2\n"
							+ "Skills: Balance +9, Climb +9, \nHide +17, Listen +13, \nMove Silently +5\n"
							+ "Feats: Skill Focus Listen, \nWeapon Finesse");

			// -----------------------BEGIN SECOND PAGE-----------------------
			// ---------------------------------------------------------------
			// -----physical descriptions-------------------------------------

			acroForm.getField("CharacterName 2").getDictionary().setString(COSName.DA, "/Helv 12 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CharacterName 2").getDictionary()))
					.setValue("Kaern Hammerfast");
			acroForm.getField("Age").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Age").getDictionary())).setValue("999");
			acroForm.getField("Height").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Height").getDictionary()))
					.setValue("5" + "'" + " 4\"");
			acroForm.getField("Weight").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Weight").getDictionary())).setValue("155 lbs");
			acroForm.getField("Eyes").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Eyes").getDictionary())).setValue("silky green");
			acroForm.getField("Skin").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Skin").getDictionary())).setValue("smooth ebon");
			acroForm.getField("Hair").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Hair").getDictionary())).setValue("wavy blue");

			// -----backstory and allies--------------------------------------

			acroForm.getField("Allies").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Allies").getDictionary())).setValue("A few allies");
			acroForm.getField("FactionName").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("FactionName").getDictionary()))
					.setValue("Faction of Demise");
			acroForm.getField("Backstory").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Backstory").getDictionary()))
					.setValue("This backstory is a short backstory.");
			acroForm.getField("Feat+Traits").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Feat+Traits").getDictionary()))
					.setValue("A feat, and a trait.");
			acroForm.getField("Treasure").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Treasure").getDictionary()))
					.setValue("I got lots of treasure.");
			acroForm.getField("CHARACTER IMAGE").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CHARACTER IMAGE").getDictionary()))
					.setValue("Place PC image here");
			acroForm.getField("Faction Symbol Image").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Faction Symbol Image").getDictionary()))
					.setValue("Place faction image here");

			// -----------------------BEGIN THIRD PAGE-----------------------
			// ---------------------------------------------------------------
			// -----spellcasting stats-------------------------------------

			acroForm.getField("Spellcasting Class 2").getDictionary().setString(COSName.DA, "/Helv 12 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spellcasting Class 2").getDictionary()))
					.setValue("Wizardly Warlock");
			acroForm.getField("SpellcastingAbility 2").getDictionary().setString(COSName.DA, "/Helv 11 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SpellcastingAbility 2").getDictionary()))
					.setValue("Intelligence");
			acroForm.getField("SpellSaveDC  2").getDictionary().setString(COSName.DA, "/Helv 11 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SpellSaveDC  2").getDictionary())).setValue("13");
			acroForm.getField("SpellAtkBonus 2").getDictionary().setString(COSName.DA, "/Helv 11 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SpellAtkBonus 2").getDictionary())).setValue("+3");

			// --------cantrips-----------------
			acroForm.getField("Spells 1014").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1014").getDictionary()))
					.setValue("Acid Splash");
			acroForm.getField("Spells 1016").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1016").getDictionary()))
					.setValue("Blade Ward");
			acroForm.getField("Spells 1017").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1017").getDictionary())).setValue("Fire Bolt");
			acroForm.getField("Spells 1018").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1018").getDictionary())).setValue("Light");
			acroForm.getField("Spells 1019").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1019").getDictionary()))
					.setValue("Minor Illusion");
			acroForm.getField("Spells 1020").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1020").getDictionary()))
					.setValue("Prestidigation");
			acroForm.getField("Spells 1021").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1021").getDictionary()))
					.setValue("Shocking Grasp");
			acroForm.getField("Spells 1022").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1022").getDictionary()))
					.setValue("True Strike");

			// --------level one spells-----------------

			acroForm.getField("SlotsTotal 19").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsTotal 19").getDictionary())).setValue("5");
			acroForm.getField("SlotsRemaining 19").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsRemaining 19").getDictionary())).setValue("4");

			// ------- Starting with spell #1

			// ((PDCheckbox) acroForm.getField("Check Box 251")).check(); //#1
			// ((PDCheckbox) acroForm.getField("Check Box 309")).check(); //#2
			// ((PDCheckbox) acroForm.getField("Check Box 3010")).check(); //#3
			// ((PDCheckbox) acroForm.getField("Check Box 3011")).check(); //#4
			// ((PDCheckbox) acroForm.getField("Check Box 3012")).check(); //#5
			// ((PDCheckbox) acroForm.getField("Check Box 3013")).check(); //#1
			// ((PDCheckbox) acroForm.getField("Check Box 3014")).check(); //#7
			// ((PDCheckbox) acroForm.getField("Check Box 3015")).check(); //#8
			// ((PDCheckbox) acroForm.getField("Check Box 3016")).check(); //#9
			// ((PDCheckbox) acroForm.getField("Check Box 3017")).check(); //#10
			// ((PDCheckbox) acroForm.getField("Check Box 3018")).check(); //#11
			// ((PDCheckbox) acroForm.getField("Check Box 3019")).check(); //#12

			acroForm.getField("Spells 1015").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1015").getDictionary()))
					.setValue(" Charm Person");
			acroForm.getField("Spells 1023").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1023").getDictionary()))
					.setValue(" Burning Hands");
			acroForm.getField("Spells 1024").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1024").getDictionary()))
					.setValue(" Color Spray");
			acroForm.getField("Spells 1025").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1025").getDictionary()))
					.setValue(" Comprehend Languages");
			acroForm.getField("Spells 1026").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1026").getDictionary()))
					.setValue(" False Life");
			acroForm.getField("Spells 1027").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1027").getDictionary()))
					.setValue(" Mage Armor");
			acroForm.getField("Spells 1028").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1028").getDictionary())).setValue(" Sleep");
			acroForm.getField("Spells 1029").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1029").getDictionary()))
					.setValue(" Protection from Evil and Good");
			acroForm.getField("Spells 1030").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1030").getDictionary()))
					.setValue(" Tenser's Floating Disk");
			acroForm.getField("Spells 1031").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1031").getDictionary()))
					.setValue(" Unseen Servant");
			acroForm.getField("Spells 1032").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1032").getDictionary()))
					.setValue(" Fog Cloud");
			acroForm.getField("Spells 1033").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1033").getDictionary()))
					.setValue(" Chromatic Orb");

			// --------level two spells-----------------

			acroForm.getField("SlotsTotal 20").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsTotal 20").getDictionary())).setValue("3");
			acroForm.getField("SlotsRemaining 20").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsRemaining 20").getDictionary())).setValue("1");

			acroForm.getField("Spells 1046").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1046").getDictionary())).setValue(" Web");
			acroForm.getField("Spells 1034").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1034").getDictionary()))
					.setValue(" Cloud of Daggers");
			acroForm.getField("Spells 1035").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1035").getDictionary())).setValue(" Darkness");
			acroForm.getField("Spells 1036").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1036").getDictionary()))
					.setValue(" Detect Thoughts");
			acroForm.getField("Spells 1037").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1037").getDictionary()))
					.setValue(" Flaming Sphere");
			acroForm.getField("Spells 1038").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1038").getDictionary()))
					.setValue(" Gust of Wind");
			acroForm.getField("Spells 1039").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1039").getDictionary()))
					.setValue(" Invisibility");
			acroForm.getField("Spells 1040").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1040").getDictionary()))
					.setValue(" Magic Mouth");
			acroForm.getField("Spells 1041").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1041").getDictionary())).setValue(" Knock");
			acroForm.getField("Spells 1042").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1042").getDictionary()))
					.setValue(" Mirror Image");
			acroForm.getField("Spells 1043").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1043").getDictionary()))
					.setValue(" Phantasmal Force");
			acroForm.getField("Spells 1044").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1044").getDictionary()))
					.setValue(" Scorching Ray");
			acroForm.getField("Spells 1045").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1045").getDictionary()))
					.setValue(" Ray of Enfeeblement");

			// --------level three spells-----------------
			acroForm.getField("SlotsTotal 21").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsTotal 21").getDictionary())).setValue("2");
			acroForm.getField("SlotsRemaining 21").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsRemaining 21").getDictionary())).setValue("0");

			// ((PDCheckbox) acroForm.getField("Check Box 315")).check(); //#1
			// ((PDCheckbox) acroForm.getField("Check Box 314")).check(); //#2
			// ((PDCheckbox) acroForm.getField("Check Box 3031")).check(); //#3
			// ((PDCheckbox) acroForm.getField("Check Box 3032")).check(); //#4
			// ((PDCheckbox) acroForm.getField("Check Box 3033")).check(); //#5
			// ((PDCheckbox) acroForm.getField("Check Box 3034")).check(); //#6
			// ((PDCheckbox) acroForm.getField("Check Box 3035")).check(); //#7
			// ((PDCheckbox) acroForm.getField("Check Box 3036")).check(); //#8
			// ((PDCheckbox) acroForm.getField("Check Box 3037")).check(); //#9
			// ((PDCheckbox) acroForm.getField("Check Box 3038")).check(); //#10
			// ((PDCheckbox) acroForm.getField("Check Box 3039")).check(); //#11
			// ((PDCheckbox) acroForm.getField("Check Box 3040")).check(); //#12
			// ((PDCheckbox) acroForm.getField("Check Box 3041")).check(); //#13

			acroForm.getField("Spells 1048").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1048").getDictionary()))
					.setValue(" Clairvoyance");
			acroForm.getField("Spells 1047").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1047").getDictionary()))
					.setValue(" Animate Dead");
			acroForm.getField("Spells 1049").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1049").getDictionary()))
					.setValue(" Counterspell");
			acroForm.getField("Spells 1050").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1050").getDictionary()))
					.setValue(" Dispel Magic");
			acroForm.getField("Spells 1051").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1051").getDictionary()))
					.setValue(" Feign Death");
			acroForm.getField("Spells 1052").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1052").getDictionary())).setValue(" Fireball");
			acroForm.getField("Spells 1053").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1053").getDictionary()))
					.setValue(" Gaseous Form");
			acroForm.getField("Spells 1054").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1054").getDictionary()))
					.setValue(" Lightning Bolt");
			acroForm.getField("Spells 1055").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1055").getDictionary()))
					.setValue(" Magic Circle");
			acroForm.getField("Spells 1056").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1056").getDictionary()))
					.setValue(" Phantom Steed");
			acroForm.getField("Spells 1057").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1057").getDictionary()))
					.setValue(" Protection from Energy");
			acroForm.getField("Spells 1058").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1058").getDictionary()))
					.setValue(" Remove Curse");
			acroForm.getField("Spells 1059").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Spells 1059").getDictionary()))
					.setValue(" Sleet Storm");

			// --------level four spells-----------------
			acroForm.getField("SlotsTotal 22").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsTotal 22").getDictionary())).setValue("7");
			acroForm.getField("SlotsRemaining 22").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsRemaining 22").getDictionary())).setValue("6");

			// --------level five spells-----------------
			acroForm.getField("SlotsTotal 23").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsTotal 23").getDictionary())).setValue("1");
			acroForm.getField("SlotsRemaining 23").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsRemaining 23").getDictionary())).setValue("1");

			// --------level six spells-----------------
			acroForm.getField("SlotsTotal 24").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsTotal 24").getDictionary())).setValue("6");
			acroForm.getField("SlotsRemaining 24").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsRemaining 24").getDictionary())).setValue("4");

			// ((PDCheckbox) acroForm.getField("Check Box 320")).check(); //#2
			// ((PDCheckbox) acroForm.getField("Check Box 321")).check(); //#1
			// ((PDCheckbox) acroForm.getField("Check Box 3060")).check(); //#3
			// ((PDCheckbox) acroForm.getField("Check Box 3061")).check(); //#4
			// ((PDCheckbox) acroForm.getField("Check Box 3062")).check(); //#5
			// ((PDCheckbox) acroForm.getField("Check Box 3063")).check(); //#6
			// ((PDCheckbox) acroForm.getField("Check Box 3064")).check(); //#7
			// ((PDCheckbox) acroForm.getField("Check Box 3065")).check(); //#8
			// ((PDCheckbox) acroForm.getField("Check Box 3066")).check(); //#9

			// --------level seven spells-----------------
			acroForm.getField("SlotsTotal 25").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsTotal 25").getDictionary())).setValue("11");
			acroForm.getField("SlotsRemaining 25").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsRemaining 25").getDictionary())).setValue("-5");

			// --------level eight spells-----------------
			acroForm.getField("SlotsTotal 26").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsTotal 26").getDictionary())).setValue("10");
			acroForm.getField("SlotsRemaining 26").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsRemaining 26").getDictionary())).setValue("5");

			// --------level nine spells-----------------
			acroForm.getField("SlotsTotal 27").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsTotal 27").getDictionary())).setValue("9");
			acroForm.getField("SlotsRemaining 27").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SlotsRemaining 27").getDictionary())).setValue("8");

			// acroForm.getField("Spells
			// 1016").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			// ((PDField) new PDTextbox(acroForm, acroForm.getField("Spells
			// 1016").getDictionary())).setValue("Detect Magic");
			// acroForm.getField("Spells
			// 1017").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			// ((PDField) new PDTextbox(acroForm, acroForm.getField("Spells
			// 1017").getDictionary())).setValue("Mage Armor");
			// acroForm.getField("Spells
			// 1018").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			// ((PDField) new PDTextbox(acroForm, acroForm.getField("Spells
			// 1018").getDictionary())).setValue("Magic Missile");
			// acroForm.getField("Spells
			// 1019").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			// ((PDField) new PDTextbox(acroForm, acroForm.getField("Spells
			// 1019").getDictionary())).setValue("Tasha's Hideous Laughter");
			// acroForm.getField("Spells
			// 1020").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			// ((PDField) new PDTextbox(acroForm, acroForm.getField("Spells
			// 1020").getDictionary())).setValue("Thunderwave");
			// acroForm.getField("Spells
			// 1021").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			// ((PDField) new PDTextbox(acroForm, acroForm.getField("Spells
			// 1021").getDictionary())).setValue("Unseen Servant");
			// acroForm.getField("Spells
			// 1022").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			// ((PDField) new PDTextbox(acroForm, acroForm.getField("Spells
			// 1022").getDictionary())).setValue("Witch Bolt");

			_pdfDocument.save("src/org/dv/data/pdfdata/PCCompletePrint.pdf");
			_pdfDocument.close();

			System.out.println("Character Sheet Complete!");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
