package org.dv.data.pdfdata;

import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDCheckbox;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.pdmodel.interactive.form.PDTextbox;

public class PdfTester {
	private static PDDocument _pdfDocument;

	public static void main(String[] args) {

		try {
			_pdfDocument = PDDocument.load("src/org/dv/data/pdfdata/Character Sheet - Form Fillable.pdf");
			_pdfDocument.setAllSecurityToBeRemoved(true);

			// int i = _pdfDocument.getNumberOfPages();

			// COSDocument doc = _pdfDocument.getDocument();
			// PDDocumentCatalog docCatalog = _pdfDocument.getDocumentCatalog();

			PDAcroForm acroForm = _pdfDocument.getDocumentCatalog().getAcroForm();

			// Character Name
			acroForm.getField("CharacterName").getDictionary().setString(COSName.DA, "/Helv 14 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CharacterName").getDictionary()))
					.setValue("Monsieur Mouseroy");

			// Class Level
			acroForm.getField("ClassLevel").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ClassLevel").getDictionary()))
					.setValue("Pacifist 19");

			// Background
			acroForm.getField("Background").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Background").getDictionary())).setValue("Charlatan");

			// Player Name
			acroForm.getField("PlayerName").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("PlayerName").getDictionary()))
					.setValue("Wilbur Walksalot");

			// Race
			acroForm.getField("Race ").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Race ").getDictionary())).setValue("Mouse");

			// Alignment
			acroForm.getField("Alignment").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Alignment").getDictionary()))
					.setValue("Chaotic Neutral");

			// Experience Points
			acroForm.getField("XP").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("XP").getDictionary())).setValue("9");

			// -----------------------BEGIN FIRST COLUMN-----------------------

			// STATS
			// Strength
			acroForm.getField("STR").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("STR").getDictionary())).setValue("5");
			// Dexterity
			acroForm.getField("DEX").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("DEX").getDictionary())).setValue("13");
			// Constitution
			acroForm.getField("CON").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CON").getDictionary())).setValue("10");
			// Intelligence
			acroForm.getField("INT").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("INT").getDictionary())).setValue("5");
			// Wisdom
			acroForm.getField("WIS").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("WIS").getDictionary())).setValue("15");
			// Charisma
			acroForm.getField("CHA").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CHA").getDictionary())).setValue("2");

			// STAT MODIFIERS
			// Strength Modifier
			acroForm.getField("STRmod").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("STRmod").getDictionary())).setValue("+1");
			// Dexterity Modifier
			acroForm.getField("DEXmod ").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("DEXmod ").getDictionary())).setValue("+2");
			// Constitution Modifier
			acroForm.getField("CONmod").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CONmod").getDictionary())).setValue("+3");
			// Intelligence Modifier
			acroForm.getField("INTmod").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("INTmod").getDictionary())).setValue("+4");
			// Wisdom Modifier
			acroForm.getField("WISmod").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("WISmod").getDictionary())).setValue("+5");
			// Charisma Modifier
			acroForm.getField("CHamod").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CHamod").getDictionary())).setValue("+6");

			// INSPIRATION
			acroForm.getField("Inspiration").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Inspiration").getDictionary())).setValue("+5");

			// PROFICIENCY BONUS
			acroForm.getField("ProfBonus").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ProfBonus").getDictionary())).setValue("+6");

			// SAVING THROWS
			// Saving Throw Strength Check Box
			((PDCheckbox) acroForm.getField("Check Box 11")).check();
			// Saving Throw Strength
			acroForm.getField("ST Strength").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Strength").getDictionary())).setValue("+4");

			// Saving Throw Dexterity Check Box
			((PDCheckbox) acroForm.getField("Check Box 18")).check();
			// Saving Throw Dexterity
			acroForm.getField("ST Dexterity").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Dexterity").getDictionary())).setValue("+5");

			// Saving Throw Constitution Check Box
			((PDCheckbox) acroForm.getField("Check Box 19")).check();
			// Saving Throw Constitution
			acroForm.getField("ST Constitution").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Constitution").getDictionary())).setValue("+6");

			// Saving Throw Intelligence Check Box
			((PDCheckbox) acroForm.getField("Check Box 20")).check();
			// Saving Throw Intelligence
			acroForm.getField("ST Intelligence").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Intelligence").getDictionary())).setValue("+7");

			// Saving Throw Wisdom Check Box
			((PDCheckbox) acroForm.getField("Check Box 21")).check();
			// Saving Throw Wisdom
			acroForm.getField("ST Wisdom").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Wisdom").getDictionary())).setValue("+8");

			// Saving Throw Charisma Check Box
			((PDCheckbox) acroForm.getField("Check Box 22")).check();
			// Saving Throw Charisma
			acroForm.getField("ST Charisma").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ST Charisma").getDictionary())).setValue("+9");

			// SKILLS
			// Acrobatics Check Box
			((PDCheckbox) acroForm.getField("Check Box 23")).check();
			// Acrobatics Skill Modifier
			acroForm.getField("Acrobatics").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Acrobatics").getDictionary())).setValue("+1");
			// Animal Handling Check Box
			((PDCheckbox) acroForm.getField("Check Box 24")).check();
			// Animal Handling Skill Modifier
			acroForm.getField("Animal").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Animal").getDictionary())).setValue("+2");
			// Arcana Check Box
			((PDCheckbox) acroForm.getField("Check Box 25")).check();
			// Arcana Skill Modifier
			acroForm.getField("Arcana").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Arcana").getDictionary())).setValue("+3");
			// Athletics Check Box
			((PDCheckbox) acroForm.getField("Check Box 26")).check();
			// Athletics Skill Modifier
			acroForm.getField("Athletics").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Athletics").getDictionary())).setValue("+4");
			// Deception Check Box
			((PDCheckbox) acroForm.getField("Check Box 27")).check();
			// Deception Skill Modifier
			acroForm.getField("Deception ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Deception ").getDictionary())).setValue("+5");
			// History Check Box
			((PDCheckbox) acroForm.getField("Check Box 28")).check();
			// History Skill Modifier
			acroForm.getField("History ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("History ").getDictionary())).setValue("+6");
			// Insight Check Box
			((PDCheckbox) acroForm.getField("Check Box 29")).check();
			// Insight Skill Modifier
			acroForm.getField("Insight").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Insight").getDictionary())).setValue("+7");
			// Intimidation Check Box
			((PDCheckbox) acroForm.getField("Check Box 30")).check();
			// Intimidation Skill Modifier
			acroForm.getField("Intimidation").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Intimidation").getDictionary())).setValue("+8");
			// Investigation Check Box
			((PDCheckbox) acroForm.getField("Check Box 31")).check();
			// Investigation Skill Modifier
			acroForm.getField("Investigation ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Investigation ").getDictionary())).setValue("+9");
			// Medicine Check Box
			((PDCheckbox) acroForm.getField("Check Box 32")).check();
			// Medicine Skill Modifier
			acroForm.getField("Medicine").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Medicine").getDictionary())).setValue("+8");
			// Nature Check Box
			((PDCheckbox) acroForm.getField("Check Box 33")).check();
			// Nature Skill Modifier
			acroForm.getField("Nature").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Nature").getDictionary())).setValue("+7");
			// Perception Check Box
			((PDCheckbox) acroForm.getField("Check Box 34")).check();
			// Perception Skill Modifier
			acroForm.getField("Perception ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Perception ").getDictionary())).setValue("+6");
			// Performance Check Box
			((PDCheckbox) acroForm.getField("Check Box 35")).check();
			// Performance Skill Modifier
			acroForm.getField("Performance").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Performance").getDictionary())).setValue("+5");
			// Persuasion Check Box
			((PDCheckbox) acroForm.getField("Check Box 36")).check();
			// Persuasion Skill Modifier
			acroForm.getField("Persuasion").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Persuasion").getDictionary())).setValue("+4");
			// Religion Check Box
			((PDCheckbox) acroForm.getField("Check Box 37")).check();
			// Religion Skill Modifier
			acroForm.getField("Religion").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Religion").getDictionary())).setValue("+3");
			// SleightofHand Check Box
			((PDCheckbox) acroForm.getField("Check Box 38")).check();
			// SleightofHand Skill Modifier
			acroForm.getField("SleightofHand").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SleightofHand").getDictionary())).setValue("+2");
			// Stealth Check Box
			((PDCheckbox) acroForm.getField("Check Box 39")).check();
			// Stealth Skill Modifier
			acroForm.getField("Stealth ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Stealth ").getDictionary())).setValue("+1");
			// Survival Check Box
			((PDCheckbox) acroForm.getField("Check Box 40")).check();
			// Survival Skill Modifier
			acroForm.getField("Survival").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Survival").getDictionary())).setValue("+2");

			acroForm.getField("Passive").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Passive").getDictionary())).setValue("+5");

			acroForm.getField("ProficienciesLang").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("ProficienciesLang").getDictionary()))
					.setValue("Mouseish\nSqueak Slang");

			// -----------------------BEGIN SECOND COLUMN-----------------------
			acroForm.getField("AC").getDictionary().setString(COSName.DA, "/Helv 14 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("AC").getDictionary())).setValue("19");

			acroForm.getField("Initiative").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Initiative").getDictionary())).setValue("+1");

			acroForm.getField("Speed").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Speed").getDictionary())).setValue("15 ft");

			acroForm.getField("HPMax").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("HPMax").getDictionary())).setValue("9");

			// Hit Points
			// acroForm.getField("HPCurrent").setValue("219");
			acroForm.getField("HPCurrent").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("HPCurrent").getDictionary())).setValue("9");

			acroForm.getField("HPTemp").getDictionary().setString(COSName.DA, "/Helv 18 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("HPTemp").getDictionary())).setValue("1");

			acroForm.getField("HDTotal").setValue("X");

			acroForm.getField("HD").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("HD").getDictionary())).setValue("�d8 (1 hp)");

			// DEATH SAVES SUCCESSES CHECK BOXES
			// Success Check Box 1
			((PDCheckbox) acroForm.getField("Check Box 12")).check();
			// Success Check Box 2
			((PDCheckbox) acroForm.getField("Check Box 13")).check();
			// Success Check Box 3
			((PDCheckbox) acroForm.getField("Check Box 14")).check();

			// DEATH SAVES FAILURES CHECK BOXES
			// Failure Check Box 1
			((PDCheckbox) acroForm.getField("Check Box 15")).check();
			// Failure Check Box 2
			((PDCheckbox) acroForm.getField("Check Box 16")).check();
			// Failure Check Box 3
			((PDCheckbox) acroForm.getField("Check Box 17")).check();

			// Weapon 1
			// acroForm.getField("Wpn Name").setValue("Machine Gun");
			acroForm.getField("Wpn Name").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn Name").getDictionary())).setValue("Machine Gun");
			// acroForm.getField("Wpn1 AtkBonus").setValue("+25");
			acroForm.getField("Wpn1 AtkBonus").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn1 AtkBonus").getDictionary())).setValue("+25");
			// acroForm.getField("Wpn1 Damage").setValue("10d20");
			acroForm.getField("Wpn1 Damage").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn1 Damage").getDictionary())).setValue("10d20");
			// Weapon 2
			// acroForm.getField("Wpn Name 2").setValue("X");
			acroForm.getField("Wpn Name 2").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn Name 2").getDictionary()))
					.setValue("Arks Toothpck");
			// acroForm.getField("Wpn2 AtkBonus ").setValue("X");
			acroForm.getField("Wpn2 AtkBonus ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn2 AtkBonus ").getDictionary())).setValue("+6");
			// acroForm.getField("Wpn2 Damage ").setValue("X");
			acroForm.getField("Wpn2 Damage ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn2 Damage ").getDictionary())).setValue("2d4+3");
			// Weapon 3
			// acroForm.getField("Wpn Name 3").setValue("X");
			acroForm.getField("Wpn Name 3").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn Name 3").getDictionary()))
					.setValue("Cat'o 9 Tails");
			// acroForm.getField("Wpn3 AtkBonus ").setValue("X");
			acroForm.getField("Wpn3 AtkBonus  ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn3 AtkBonus  ").getDictionary())).setValue("+2");
			// acroForm.getField("Wpn3 Damage ").setValue("X");
			acroForm.getField("Wpn3 Damage ").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Wpn3 Damage ").getDictionary())).setValue("1d6");

			acroForm.getField("AttacksSpellcasting").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("AttacksSpellcasting").getDictionary())).setValue(
					"Base Attack/Grapple: +0/-21\n" + "Attack: Bite +9 melee (1)\n" + "Full Attack: Bite +9 melee (1)");

			acroForm.getField("CP").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("CP").getDictionary())).setValue("999");
			acroForm.getField("SP").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("SP").getDictionary())).setValue("999");
			acroForm.getField("EP").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("EP").getDictionary())).setValue("999");
			acroForm.getField("GP").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("GP").getDictionary())).setValue("999");
			acroForm.getField("PP").getDictionary().setString(COSName.DA, "/Helv 9 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("PP").getDictionary())).setValue("999");

			acroForm.getField("Equipment").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Equipment").getDictionary())).setValue("Fur");

			// -----------------------BEGIN THIRD COLUMN-----------------------
			acroForm.getField("PersonalityTraits ").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("PersonalityTraits ").getDictionary()))
					.setValue("Environment: Any\n" + "Organization: Mischief (10-100)");

			acroForm.getField("Ideals").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Ideals").getDictionary()))
					.setValue("Squeek! Something small darts \nout of the corner of your eye");

			acroForm.getField("Bonds").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Bonds").getDictionary()))
					.setValue("and flees into a small hole \nin the wall.");

			acroForm.getField("Flaws").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Flaws").getDictionary())).setValue("Eeek! A mouse!");

			acroForm.getField("Features and Traits").getDictionary().setString(COSName.DA, "/Helv 10 Tf 0 g");
			((PDField) new PDTextbox(acroForm, acroForm.getField("Features and Traits").getDictionary()))
					.setValue("Speed: 15 ft. (3 squares), \nclimb 15 ft\n"
							+ "Armor Class: 19 (+8 size, +1 Dex), \ntouch 19, flat-footed 18\n"
							+ "Space/Reach: � ft./0 ft.\n" + "Special Qualities: Low-light vision, \nscent\n"
							+ "Saves: Fort +2, Ref +3, Will +2\n"
							+ "Skills: Balance +9, Climb +9, \nHide +17, Listen +13, \nMove Silently +5\n"
							+ "Feats: Skill Focus Listen, \nWeapon Finesse");

			// PDResources res = acroForm.getDefaultResources();

			// Set fonts
			// String fieldfont = "";
			// Iterator fieldsIter = acroForm.getFields().iterator();
			// while(fieldsIter.hasNext()) {
			// PDField field = (PDField) fieldsIter.next();
			//
			// if
			// (field.getFullyQualifiedName().trim().equalsIgnoreCase("CharacterName"))
			// {
			// fieldfont = "/Helv 14 Tf 0 g";
			// } else if
			// (field.getFullyQualifiedName().trim().equalsIgnoreCase("STR") ||
			// field.getFullyQualifiedName().trim().equalsIgnoreCase("DEX") ||
			// field.getFullyQualifiedName().trim().equalsIgnoreCase("CON") ||
			// field.getFullyQualifiedName().trim().equalsIgnoreCase("INT") ||
			// field.getFullyQualifiedName().trim().equalsIgnoreCase("WIS") ||
			// field.getFullyQualifiedName().trim().equalsIgnoreCase("CHA")) {
			// fieldfont = "/Helv 18 Tf 2 Tr .5 w 0 g";
			// } else {
			// fieldfont = "/Helv 10 Tf 0 g";
			// }
			// field.getDictionary().setString(COSName.DA, fieldfont);
			// ((PDField) new PDTextbox(acroForm,
			// field.getDictionary())).setValue(field.getValue());

			// if (field.getFullyQualifiedName().equalsIgnoreCase("playername"))
			// {
			// field.setValue("Wilbur Walksalot");
			// } else if
			// (field.getFullyQualifiedName().equalsIgnoreCase("classlevel")) {
			// field.setValue("Warlock 10");
			// } else if
			// (field.getFullyQualifiedName().equalsIgnoreCase("charactername"))
			// {
			// field.setValue("Mageminon Meanderer");
			// } else if
			// (field.getFullyQualifiedName().equalsIgnoreCase("race")) {
			// field.setValue("Ghost");
			// } else if
			// (field.getFullyQualifiedName().equalsIgnoreCase("alignment")) {
			// field.setValue("Chaotically Chaotic");
			// } else if
			// (field.getFullyQualifiedName().equalsIgnoreCase("background")) {
			// field.setValue("Charlatan");
			// }

			// field.getDictionary().setInt("Ff",1);
			// COSDictionary dict = ((PDField) field).getDictionary();
			// COSString defaultAppearance = (COSString)
			// dict.getDictionaryObject(COSName.DA);
			//
			// dict.setString(COSName.DA, "/Helv 10 Tf 0 g");
			// //dict.setString(COSName.DA, "/Helv 10 Tf 2 Tr .5 w 0 g");
			//
			//
			//
			// if (field instanceof PDTextbox)
			// {
			// field = new PDTextbox(acroForm, dict);
			// ((PDField) field).setValue(field.getValue());
			// }

			// System.out.println(field.getFullyQualifiedName()); // + " " +
			// defaultAppearance);
			// field.setReadonly(true);

			// if
			// (field.getFullyQualifiedName().trim().equalsIgnoreCase("race")) {
			// System.out.println("|"+field.getFullyQualifiedName()+"|");
			// } else if
			// (field.getFullyQualifiedName().trim().equalsIgnoreCase("features
			// and traits")) {
			// System.out.println("|"+field.getFullyQualifiedName()+"|");
			// } else {
			// System.out.println(field.getFullyQualifiedName() + " " +
			// field.getFieldType() + " " +
			// field.getFieldFlags() + " " +
			// field.getValue());
			// }
			// }

			// PDField firstNameField = pdAcroForm.getField("firstName");
			// PDField lastNameField = pdAcroForm.getField("lastName");

			// COSDictionary acroFormDict = acroForm.getDictionary();
			// COSArray fields = (COSArray)
			// acroFormDict.getDictionaryObject("Fields");
			// fields.clear();

			_pdfDocument.save("src/org/dv/data/pdfdata/Character Sheet - Form Fillable_MOD.pdf");
			_pdfDocument.close();

			// PDDocument doc =
			// PDDocument.load("src/org/dv/data/pdfdata/Character Sheet - Form
			// Fillable.pdf");
			// doc.setAllSecurityToBeRemoved(true);
			//
			// PDAcroForm form = doc.getDocumentCatalog().getAcroForm();
			//
			//
			//
			//
			//
			// //PDXFA xfa = form.getXFA();
			// //COSBase cos = xfa.getCOSObject();
			// COSStream coss = (COSStream) form.getXFA().getCOSObject(); //cos;
			// InputStream cosin = coss.getUnfilteredStream();
			// Document documentXML =
			// DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(cosin);
			//
			//
			//
			// //Document documentXML =
			// DocumentBuilderFactory.newInstance().newDocumentBuilder().parse((InputStream)
			// form.getXFA().getDocument());
			//
			// //Document documentXML = form.getXFA().getDocument();
			//
			//
			//
			//
			//
			// NodeList dataElements =
			// documentXML.getElementsByTagName("xfa:data");
			// if (dataElements != null) {
			// for (int i = 0; i < dataElements.getLength(); i++) {
			// //setXFAFields(dataElements.item(i), values);
			// System.out.println(dataElements.item(i));
			// }
			// }
			//
			//
			// COSStream cosout = new COSStream(new RandomAccessBuffer());
			//
			//
			// TransformerFactory.newInstance().newTransformer()
			// .transform(new DOMSource(documentXML), new
			// StreamResult(cosout.createUnfilteredStream()));
			//
			//
			//
			// form.setXFA(new PDXFA(cosout));
			//
			//
			//
			// FileOutputStream fios = new FileOutputStream(new
			// File("C:/Temporary/Character Sheet - Form Fillable A.pdf"));
			// documentXML.save(fios);
			// document.close();
			// try {
			// fios.flush();
			// } finally {
			// fios.close();
			// }

		} catch (Exception e) {
			e.printStackTrace();
		}

		// System.out.println("I'm Done!");

	}
}
